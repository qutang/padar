# `radar` python package

Short for _Processing Accelerometer Data and Activity Recognition_

This package is for,

1. Batch processing files stored in mhealth specification
2. Train, test and validate machine learning algorithms

# Commandline interfaces

1. `rad`: batch processing interface
2. `par`: machine learning training and testing interface

